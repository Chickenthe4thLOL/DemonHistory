import webbrowser

#lol  :)
webbrowser.open("https://www.google.com/search?q=free+dirty+feet+pics&oq=peter&gs_lcrp=EgZjaHJvbWUqBggAEEUYOzIGCAAQRRg7MgYIARBFGDkyBggCEEUYO9IBCDIwNzRqMGo3qAIAsAIA&sourceid=chrome&ie=UTF-8")
webbrowser.open("https://www.google.com/search?q=two+girls+one+cup&oq=peter&gs_lcrp=EgZjaHJvbWUqBggAEEUYOzIGCAAQRRg7MgYIARBFGDkyBggCEEUYO9IBCDIwNzRqMGo3qAIAsAIA&sourceid=chrome&ie=UTF-8")
webbrowser.open("https://www.google.com/search?q=elon+musk+porn&oq=peter&gs_lcrp=EgZjaHJvbWUqBggAEEUYOzIGCAAQRRg7MgYIARBFGDkyBggCEEUYO9IBCDIwNzRqMGo3qAIAsAIA&sourceid=chrome&ie=UTF-8")
webbrowser.open("https://www.google.com/search?q=why+is+my+teacher+on+pornhub&oq=peter&gs_lcrp=EgZjaHJvbWUqBggAEEUYOzIGCAAQRRg7MgYIARBFGDkyBggCEEUYO9IBCDIwNzRqMGo3qAIAsAIA&sourceid=chrome&ie=UTF-8")
webbrowser.open("https://988lifeline.org/")
webbrowser.open("https://www.youtube.com/watch?v=7Kn0V5mpJe4")

